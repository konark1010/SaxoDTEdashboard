import { retryWhen } from 'rxjs-compat/operator/retryWhen';


export class RepositoryGridConfig {


    static loadGridConfigs() {
        const gridConfig = {
            mode: 'internal',
            selectMode: 'single',
            hideSubHeader: false,
            actions: {
                columnTitle: 'User-Actions',
                add: true,
                position: 'right',
                delete: true,
                edit: true,

                custom: [
                    // tslint:disable-next-line:max-line-length
                    { name: 'addmoreanswer', title: '<i class="fab fa-artstation" data-toggle="tooltip" data-placement="top" title="View/Add/Edit Linked Answers"> </i>' },
                    // tslint:disable-next-line:max-line-length
                    { name: 'addsimilarquest', title: '<i class="fas fa-question-circle" data-toggle="tooltip" data-placement="top" title="Add similar questions"></i>' }
                ]
            },
            edit: {
                confirmSave: true,
                // tslint:disable-next-line:max-line-length
                editButtonContent: '<i class="fas fa-user-edit" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="Edit"></i>',
                saveButtonContent: '<i class="fas fa-save" aria-hidden="true">Save</i>',
                cancelButtonContent: '<i class="fas fa-ban" aria-hidden="true">Cancel</i>'
            },
            add: {
                confirmCreate: true,
                addButtonContent: '<i class="fas fa-plus-square" aria-hidden="true"><span>Add Q&A</span></i>',
                createButtonContent: '<i class="fas fa-save" aria-hidden="true">Save</i>',
                cancelButtonContent: '<i class="fas fa-ban" aria-hidden="true">Cancel</i>'
            },
            delete: {
                confirmDelete: true,
                // tslint:disable-next-line:max-line-length
                deleteButtonContent: '<i class="fas fa-trash-alt" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="Delete From UI"></i>'
            },
            pager: {
                display: true,
                perPage: 10
            },
            rowClassFunction: (row) => {
               // console.log(row)
                if (row.isSelected && row.data.ansewer !== 'Not Answered') {
                    return 'rowSelected';
                } else if (row.isInEditing) {
                    return 'isInEditing';
                } else if (row.data.ansewer === 'Not Answered') {
                    return 'unasnwered';
                } else { return 'notSelected'; }
            },
            columns: {
                question: {
                    title: 'Question',
                    width: '25%',
                    // filter: false,
                    //   editable: false
                },
                ansewer: {
                    title: 'Answer',
                    width: '25%',
                    // editable: false
                    valuePrepareFunction: (value) => {
                        if (value === null) {
                            return 'Not Answered';
                        } else {
                            return value;
                        }
                    }
                },
                rating: {
                    title: 'Rating',
                    editor: {
                        type: 'list',
                        config: {
                            list: [{ value: 1, title: '1' },
                            { value: 2, title: '2' },
                            { value: 3, title: '3' },
                            { value: 4, title: '4' },
                            { value: 5, title: '5' }]

                        }
                    }
                    // filter: false,
                    // editable: false,
                    // width: '16%'
                },
                userRating: {
                    title: 'User Rating',
                    editable: false
                    // editable: false,
                    // valuePrepareFunction: (value) => {
                    //     if (value === null) {
                    //         return 'Not Assigned';
                    //     } else {
                    //         return value;
                    //     }
                    // }
                },
                review: {
                    title: 'Reviewed',
                    // editable: false
                    editor: {
                        type: 'list',
                        config: {
                            list: [{ value: true, title: 'Yes' },
                            { value: false, title: 'No' }]
                        }
                    },
                    valuePrepareFunction: (value) => {
                        if (value === true) {
                            return 'Yes';
                        } else {
                            return 'No';
                        }
                    }
                },
                lastReviewedBy: {
                    title: 'Reviewed By',
                    editable: false,
                    // filter: false
                },
                lastReviewed: {
                    title: 'Last Reviewed',
                    editable: false,
                    // filter: false
                },
                // linkedAnswers: {
                //     title: 'Linked Answer',
                //     editor: {
                //         type: 'checkbox'
                //     }
                // }

            }

        };
        return gridConfig;
    }
    static loadModalGridConfigs() {
        const modalGridConfig = {
            actions: {
                columnTitle: 'User-Actions',
                add: true,
                position: 'right',
                delete: true,
                edit: true,
            },
            edit: {
                confirmSave: true,
                // tslint:disable-next-line:max-line-length
                editButtonContent: '<i class="fas fa-user-edit" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="Edit"><br /></i>',
                saveButtonContent: '<i class="fas fa-save" aria-hidden="true">Update</i>',
                cancelButtonContent: '<i class="fas fa-ban" aria-hidden="true">Cancel</i>'
            },
            add: {
                confirmCreate: true,
                addButtonContent: '<i class="fas fa-plus-square" aria-hidden="true"><br />Add Answers</i>',
                createButtonContent: '<i class="fas fa-save" aria-hidden="true">Save</i>',
                cancelButtonContent: '<i class="fas fa-ban" aria-hidden="true">Cancel</i>'
            },
            delete: {
                confirmDelete: true,
                // tslint:disable-next-line:max-line-length
                deleteButtonContent: '<i class="fas fa-trash-alt" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="Delete"<br /></i>'
            },
            pager: {
                display: true,
                perPage: 5
            },
            rowClassFunction: (row) => {
                if (row.isSelected) {
                    return 'rowSelected';
                } else {
                    return 'notSelected';
                }
            },
            columns: {
                ansewer: {
                    title: 'Answer',
                    width: '40%',
                    // editable: false
                    filter: false,
                },
                rating: {
                    title: 'Rating',
                    filter: false,
                    // editable: false,
                    // width: '16%'
                },
                userRating: {
                    title: 'User Rating',
                    filter: false,
                    editable: false,
                    // valuePrepareFunction: (value) => {
                    //     if (value === null) {
                    //         return 'Not Assigned';
                    //     } else {
                    //         return value;
                    //     }
                    // }
                },
                review: {
                    title: 'Reviewed',
                    valuePrepareFunction: (value) => {
                        if (value === true) {
                            return 'Yes';
                        } else {
                            return 'No';
                        }
                    },
                    filter: false,
                    editable: false
                },
                lastReviewedBy: {
                    title: 'Reviewed By',
                    editable: false,
                    filter: false
                },
                lastReviewed: {
                    title: 'Last Reviewed',
                    editable: false,
                    filter: false
                },
            }

        };
        return modalGridConfig;
    }
    static loadAddSimQuestGridConfigs() {
        const addSimQuestGridConfigs = {
            actions: {
                columnTitle: 'User-Actions',
                add: true,
                position: 'right',
                delete: true,
                edit: true,
            },
            edit: {
                confirmSave: true,
                editButtonContent: '<i class="fas fa-user-edit" aria-hidden="true"><br /></i></i>',
                saveButtonContent: '<i class="fas fa-save" aria-hidden="true">Update</i>',
                cancelButtonContent: '<i class="fas fa-ban" aria-hidden="true">Cancel</i>'
            },
            add: {
                confirmCreate: true,
                addButtonContent: '<i class="fas fa-plus-square" aria-hidden="true"><br />Add Similar Questions</i>',
                createButtonContent: '<i class="fas fa-save" aria-hidden="true">Save</i>',
                cancelButtonContent: '<i class="fas fa-ban" aria-hidden="true">Cancel</i>'
            },
            delete: {
                confirmDelete: true,
                deleteButtonContent: '<i class="fas fa-trash-alt" aria-hidden="true"><br /></i>'
            },
            pager: {
                display: true,
                perPage: 10
            },
            // rowClassFunction: (row) => {
            //   switch (row.data.assistStatus) {
            //     case 'Assigned':
            //       return 'assigned';
            //     case 'Unassigned':
            //       return 'unnasigned';
            //     case 'Not Assigned':
            //       return 'unnasigned';
            //     case 'Close':
            //       return 'closecall';
            //   }
            // },
            columns: {
                question: {
                    title: 'Similar Question',
                    width: '80%',
                    // editable: false
                    filter: false,
                },
            }

        };
        return addSimQuestGridConfigs;
    }
}
